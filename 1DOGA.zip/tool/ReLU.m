function y=ReLU(x,n)
%% ReLU
y=max(0,x).^n;
end