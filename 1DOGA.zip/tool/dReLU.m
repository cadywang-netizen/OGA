function y=dReLU(x,n,m)
%% derivatives of ReLU
% y1=zeros(size(x));
% y1(x>0)=1;
if n>1
 y=factorial(n)/factorial(n-m)*max(0,x).^(n-m); %.*y1.^m;
elseif n==1
 y=x>0;
end
