
x=0; y=1; w1=1; w2=0;b=1; k=2;theta=pi/20;

result=activationsym(x,y,w1,w2,b,theta,k);
resultx=dxactivationsym(x,y,w1,w2,b,theta,k);
resulty=dyactivationsym(x,y,w1,w2,b,theta,k);
ssss=1;